<?php
extract($_POST);
$id=$_POST['pnr'];
$db=mysqli_connect('localhost:3306','root','','trains');
if(isset($db)){
	$sql1="SELECT * FROM `1` where id=$id";
	$sql2="SELECT * FROM `2` where id=$id";
	$a=mysqli_query($db,$sql1);
	$b=mysqli_query($db,$sql2);
	$s=mysqli_num_rows($a);
	$t=mysqli_num_rows($b);
	if($s)
	{
		$sql1="DELETE FROM `1` where id=$id";
		$result1=mysqli_query($db,$sql1);
		echo "cancel";
		header('Location:cancelled.html');
	}
	elseif ($t) {
		$sql1="DELETE FROM `2` where id=$id";
		$result1=mysqli_query($db,$sql1);
		echo "cancel";
		header('Location:cancelled.html');
	}
	else
	{
		header('Location:not.html');
	}


	
}