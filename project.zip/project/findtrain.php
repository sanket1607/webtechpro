<?php 
extract($_GET);
$from = $_GET['s1'];
$to=$_GET['s2'];
if($from=='SBC' && $to=='UBL')
{
	header('Location:train1.html');
}
else
{
	header('Location:train2.html');

}
?>