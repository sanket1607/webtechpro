<?php
extract($_POST);
$id=$_POST['pnr'];

$db=mysqli_connect('localhost:3306','root','','trains');
if(isset($db))
{
	$sql1="SELECT * FROM `1` where id=$id";
	$sql2="SELECT * FROM `2` where id=$id";
	$a=mysqli_query($db,$sql1);
	$b=mysqli_query($db,$sql2);
	$s=mysqli_num_rows($a);
	$t=mysqli_num_rows($b);
	if($s || $t)
	{
		header('Location:confirm.html');
	}
	else
	{
		header('Location:not.html');
	}

}
