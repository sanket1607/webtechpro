<?php
extract($_POST);
$db=mysqli_connect('localhost:3306','root','','trains');
if(isset($db)){


	$sql1="SELECT * FROM `1`";
	

	
	$result1=mysqli_query($db,$sql1);
	$row = mysqli_fetch_array($result1);
	$count = 1;
	$t=mysqli_num_rows($result1);
	while($t){
		$count = $count + 1;
		$t = $t-1;
	}
	$id = rand(10,1000);

	$sql = "INSERT INTO `1` (id,seatno,passenger,age,gender,phone,email)
	VALUES ('".$id."','".$count."','".$name."','".$age."','".$gender."','".$phone."','".$email."')";
	$result=mysqli_query($db,$sql);
	header('Location:booked.html');

}



?>
